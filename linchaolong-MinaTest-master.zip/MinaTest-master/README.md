Mina框架的使用

博客地址：http://blog.csdn.net/linchaolong
